<?php   
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH. "/libraries/REST_Controller.php";
class Repost extends REST_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('Repost_model','repost');
        $this->load->model('quoteshare_model');
       // $this->load->model('Repost_model','repost');
        $this->load->helper('string');
        $this->load->model('Followunfollow_model','follow');
    }

    //this function is used to report the feed
     public function feedReport_post(){
            $feed_id=$this->input->post('feed_id');  
            $user_id=$this->input->post('user_id');
            $session_key=$this->input->post('session_key');
            $report_text=$this->input->post('report_text');
            $title=$this->input->post('title');
            if(empty($feed_id && $user_id && $report_text)){
                 $this->response([
                    'status'=>FALSE,
                    'message'=>'Please fill all the detail',
                    ],REST_Controller::HTTP_NOT_FOUND);
            }
            else{
                $is_validate_user=$this->quoteshare_model->check_user_validation($user_id,$session_key);
                if($is_validate_user==1){
                        $is_AlreadyExist=$this->repost->isfeedthere($feed_id);
                        if($is_AlreadyExist){
                            $report=array(
                                            'feed_id'=>$feed_id,
                                            'user_id'=>$user_id,
                                            'report_text'=>$report_text,
                                            'title'=>$title,
                                        );
                            $feed_report=$this->repost->feedReport($report);
                            if($feed_report){
                                $this->response([
                                    'status'=>TRUE,
                                    'message'=>'Report Successfullly',
                                    'data'=>$feed_report,
                                    ],REST_Controller::HTTP_OK);
                            }
                                else{
                                        $this->response([
                                        'status'=>FALSE,
                                        'message'=>'Report Unsuccessfullly',
                                        ],REST_Controller::HTTP_NOT_FOUND);
                                }
                            }
                        
                        else{
                            $this->response([
                                'status'=>FALSE,
                                'message'=>'No Feed Found for report',
                                'data'=>$is_AlreadyExist,
                                ],REST_Controller::HTTP_NOT_FOUND);
                        }
                }
               else{
                $this->response([
                    'status'=>FALSE,
                    "message"=>"Unauthorized user",
                    'data'=>$is_validate_user,
                    ],REST_Controller::HTTP_NOT_FOUND);
               } 
            }
        }
    //This function is used to foryou search
        public function forYouSearch_post(){
            $user_id=$this->input->post('user_id');
            $session_key=$this->input->post('session_key');
            $is_validate_user=$this->quoteshare_model->check_user_validation($user_id,$session_key);
            if($is_validate_user==1){
                    $foryou=$this->input->post('keyword');
                    $match=$this->repost->ForYouSearch($foryou);
                    if($match){
                        $search=array();
                        foreach($match as $foryousearch){
                            $totalFollowers=$this->follow->totalFollowers($foryousearch->user_id);
                            $searchresult=array('user_id'=>$foryousearch->user_id,
                                'user_type'=>$foryousearch->user_type,
                                'full_name'=>$foryousearch->full_name,
                                'user_name'=>$foryousearch->user_name,
                                'user_picture'=>$foryousearch->picture,
                                'total_followers'=>$totalFollowers,
                            );
                            array_push($search,$searchresult);
                         }
                        if($search){
                            $this->response([
                            'status'=>TRUE,
                            'message'=>'ForYou Search',
                            'data'=>$search,
                            ],REST_Controller::HTTP_OK);
                        }
                            else{
                                $this->response([
                                    'status'=>FALSE,
                                    'message'=>'No Result Found For'." ".$foryou,
                                    'data'=>$search,
                                    ],REST_Controller::HTTP_NOT_FOUND);
                        }
                 }
                    else{
                         $this->response([
                            'status'=>FALSE,
                            'message'=>'No Result Found',
                            'data'=>0,
                        ],REST_Controller::HTTP_NOT_FOUND);
                    }
                }
                else{
                    $this->response([
                        'status'=>FALSE,
                        "message"=>"Unauthorized user",
                        'data'=>$is_validate_user,
                        ],REST_Controller::HTTP_NOT_FOUND);
                }
         }

         //This function is used for repost
    public function repost_post(){
        $feed_id=$this->input->post('feed_id');
        $user_id=$this->input->post('user_id');
        $session_key=$this->input->post('session_key');
        if(empty($feed_id && $user_id && $session_key )){
            return false;
        }
        $is_validate_user=$this->quoteshare_model->check_user_validation($user_id,$session_key);
        if($is_validate_user==1){
        //it will check post is already share or not
        $is_AlreadyExist=$this->repost->isfeedthere($feed_id);
         if($is_AlreadyExist){
                $is_repost=$this->repost->is_repost($user_id,$feed_id);
                 if($is_repost){
                        $delete_repost=$this->repost->deleteRepost($user_id,$feed_id);
                        $delete_reshareCount=$this->repost->deleteResharingcount($user_id,$feed_id);
                        if($delete_repost && $delete_reshareCount){
                                $this->response([
                                    'status'=>TRUE,
                                    'message'=>'Unshare repost',
                                ],REST_Controller::HTTP_OK);
                            }
                    }
                     else{
                             //this will get the feed data with feed_id
                            $match=$this->repost->feed_detail($feed_id);
                            $olduser_id=$match->user_id;
                            //here we are getting the data single single column data
                            $repost=array(
                                'category_id'=>$match->category_id,
                                'user_id'=>$user_id,
                                'image'=>$match->image,
                                'quote'=>$match->quote,
                                'caption'=>$match->caption,
                                'author_id'=>$match->author_id,
                                'booker_id'=>$match->booker_id,
                                'tagger_id'=>$match->tagger_id,
                                'tagger_id'=>$match->tagger_id,
                                'parent_id'=>$match->feed_id,
                            );
                            $resharingCount=array('user_id'=>$user_id,
                                                'feed_id'=>$feed_id,);
                            //this will insert the old feed data into new feed
                            $result=$this->repost->insert('feeds',$repost);
                            $resharingTable=$this->repost->insert('resharingcount',$resharingCount);
                            //it will get the feed detail
                            $newRepost=$this->repost->feed_detail($result);
                            $newUid=$newRepost->user_id;
                            $newFeedId=$newRepost->feed_id;
                            //this function will be get the original user data
                            $getOriginalFeedUserData=$this->quoteshare_model->getuserdata($olduser_id);
                                //Here we get the original user data
                            $originaluid=$getOriginalFeedUserData->user_id;
                            $originalFname=$getOriginalFeedUserData->full_name;
                            $originalUser_name=$getOriginalFeedUserData->user_name;
                            $originalUtype=$getOriginalFeedUserData->user_type;
                            $originalUicture=$getOriginalFeedUserData->picture;

                                $originalpostdata=array('Realuserid'=>$originaluid,
                                        'realfullName'=>$originalFname,
                                        'realUsername'=>$originalUser_name,
                                        'realusertype'=>$originalUtype,            
                                        'realuserpicture'=>$originalUicture,            
                                    );
                            //this function will show the user detail and feed detail
                            $Repostdata=$this->repost->view_feeds_detail($newUid,$newFeedId);
                            $merged_arr = array_merge($originalpostdata,$Repostdata);
                            $this->response([
                                'status'=>TRUE,
                                'message'=>'Repost Feed data',
                                'data'=>$merged_arr,
                            ],REST_Controller::HTTP_OK);
                     }
             }
                    else{  
                            $this->response([
                                'status'=>FALSE,
                            'message'=>'post is not found for repost',
                            'data'=>$is_AlreadyExist,
                            ],REST_Controller::HTTP_NOT_FOUND);
                        }
                    }

                    else{
                        $this->response([
                            'status'=>FALSE,
                            "message"=>"Unauthorized user",
                            'data'=>$is_validate_user,
                            ],REST_Controller::HTTP_NOT_FOUND);
                    }
    }

    //This function is used to get the repost feed of the user
    public function getRepostFeeds_post(){
            $user_id=$this->input->post('user_id');
            $validation=$this->repost->check_repost($user_id);
            if($validation==0){
                $this->response([
                    'status'=>FALSE,
                    'message'=>'No Repost Data Found',
                    'data'=>$validation,
                ],REST_Controller::HTTP_NOT_FOUND);
            }
            else{
                        $match=$this->repost->getMyRepostFeeds($user_id);//it will get the repost feeds
                         $repostAllData=array();
                    foreach($match as $repostFeeds){
                                $realFeedDetail=$this->repost->feed_detail($repostFeeds->parent_id);
                            //      print_r($realFeedDetail);
                                $userdetail=$this->repost->getUserDetail($realFeedDetail->user_id);
                            //     print_r($userdetail);
                                $mergedata=array(
                            'feed_id'=>$repostFeeds->feed_id,
                            'category_id'=>$repostFeeds->category_id,
                            'user_id'=>$repostFeeds->user_id,
                            'quote_image'=>$repostFeeds->image,
                            'quote'=>$repostFeeds->quote,
                            'caption'=>$repostFeeds->caption,
                            'author_id'=>$repostFeeds->author_id,
                            'booker_id'=>$repostFeeds->booker_id,
                            'tagger_id'=>$repostFeeds->tagger_id,
                            'parent_id'=>$repostFeeds->parent_id,
                            'created_at'=>$repostFeeds->created_at,
                            'userFull_Name'=>$repostFeeds->full_name,
                            'user_picture'=>$repostFeeds->picture,
                            'repostCount'=>$repostFeeds->RepostCount,
                            'TotalLikes'=>$repostFeeds->totalLikes,
                            'TotalRepost'=>$repostFeeds->totalQuotes,
                            'IsLiked'=>$repostFeeds->isLiked,
                            'IsRepost'=>$repostFeeds->isRepost,
                            'TotalComments'=>$repostFeeds->totalComments,
                            'originalUser_id'=>$userdetail->user_id,
                            'originalFull_name'=>$userdetail->full_name,
                            'originalUser_name'=>$userdetail->user_name,
                            'originaluser_type'=>$userdetail->user_type,
                            'originaluser_picture'=>$userdetail->picture,
                            );
                        array_push($repostAllData,$mergedata);
                    }         
                    $this->response([
                        'status'=>TRUE,
                        'message'=>'Repost Feed data',
                        'data'=>$repostAllData,
                    ],REST_Controller::HTTP_OK);
             }
     }
     public function getRepostFeedsBYPopularity_post()
     {
        $user_id=$this->input->post('user_id');
        $validation=$this->repost->check_repost($user_id);
        if($validation==0){
                $this->response([
                'status'=>FALSE,
                'message'=>'No Repost Data Found',
                'data'=>$validation,
                ],REST_Controller::HTTP_NOT_FOUND);
            }
        else{
                    $match=$this->repost->getMyRepostFeedsByPopularity($user_id);//it will get the repost feeds
                     $repostAllData=array();
                foreach($match as $repostFeeds){
                            $realFeedDetail=$this->repost->feed_detail($repostFeeds->parent_id);
                        //      print_r($realFeedDetail);
                            $userdetail=$this->repost->getUserDetail($realFeedDetail->user_id);
                        //     print_r($userdetail);
                            $mergedata=array(
                        'feed_id'=>$repostFeeds->feed_id,
                        'category_id'=>$repostFeeds->category_id,
                        'user_id'=>$repostFeeds->user_id,
                        'quote_image'=>$repostFeeds->image,
                        'quote'=>$repostFeeds->quote,
                        'caption'=>$repostFeeds->caption,
                        'author_id'=>$repostFeeds->author_id,
                        'booker_id'=>$repostFeeds->booker_id,
                        'tagger_id'=>$repostFeeds->tagger_id,
                        'parent_id'=>$repostFeeds->parent_id,
                        'created_at'=>$repostFeeds->created_at,
                        'userFull_Name'=>$repostFeeds->full_name,
                        'user_picture'=>$repostFeeds->picture,
                        'repostCount'=>$repostFeeds->RepostCount,
                        'TotalLikes'=>$repostFeeds->totalLikes,
                        'TotalRepost'=>$repostFeeds->totalQuotes,
                        'IsLiked'=>$repostFeeds->isLiked,
                        'IsRepost'=>$repostFeeds->isRepost,
                        'TotalComments'=>$repostFeeds->totalComments,
                        'originalUser_id'=>$userdetail->user_id,
                        'originalFull_name'=>$userdetail->full_name,
                        'originalUser_name'=>$userdetail->user_name,
                        'originaluser_type'=>$userdetail->user_type,
                        'originaluser_picture'=>$userdetail->picture,
                        );
                    array_push($repostAllData,$mergedata);
                }         
                $this->response([
                    'status'=>TRUE,
                    'message'=>'Repost Feed data',
                    'data'=>$repostAllData,
                ],REST_Controller::HTTP_OK);
         }
     }
}