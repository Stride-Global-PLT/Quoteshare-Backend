<?php
defined('BASEPATH') OR exit('No direct script access allowed');
		//This function is used to check the validation of the input fields
		function checkRequired($array){
				$requried = "";
			foreach($array as $key => $value) {
				if ($value==''){
					$requried .= $key.',';
				}
			}
			if($requried!=""){
				return rtrim($requried,',');
			}
			else{
				return false;
			}
		}


	//This function is used to send the notification on Android device
		function andiPush($token,$message,$section){

			$token = $token;
			$message = addslashes($message);
			//$badge = $badge;

			// Replace with the real server API key from Google APIs
			$apiKey = "AAAAshm-Uc0:APA91bH9ad4VAdTdOUHPwxKoZx9ZVXWbBN_bUhnhcS9cqgXYB187T03HoIlbjdGMk8jXDez7Ox0V_tDDYOHLuhlxB3oj8iFk6ryDItqwAAtrDO_RhtpRfrMPh-HsmgqxjfifylOyh4gW";

			// Set POST variables
			//$url = 'https://android.googleapis.com/gcm/send';
			$url = 'https://fcm.googleapis.com/fcm/send';

			$fields = array(
			'registration_ids'  => array($token),
			'data'              => array( "message" => $message,'badge'=>'1','section'=>$section)
			);
			//,'joinGroupId'=>$joinGroupLastInserId
			//print_r($fields);exit;
			$headers = array(
			'Authorization: key=' . $apiKey,
			'Content-Type: application/json'
			);

			// Open connection
			$ch = curl_init();
			// Set the url, number of POST vars, POST data
			curl_setopt( $ch, CURLOPT_URL, $url );
			curl_setopt( $ch, CURLOPT_POST, true );
			curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
			curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $fields ) );
			// Execute post
			$result = curl_exec($ch);
			// Close connection
			curl_close($ch);
			return $res = json_decode($result,true);
			//print_R($res);
			//exit;
			/*return $var['success'];*/
	}
	//This function is used to send the push notification
	function applePush($token,$message,$badge=0,$section){
			$deviceToken = $token;
			// Put your private key's passphrase here:
			$passphrase = '123';

			// Put your alert message here:
			$message = $message;

			////////////////////////////////////////////////////////////////////////////////

			$ctx = stream_context_create();
			stream_context_set_option($ctx, 'ssl', 'local_cert', './certificate/ck.pem');
			stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

			// Open a connection to the APNS server
			// $fp = stream_socket_client(
			// 'ssl://gateway.sandbox.push.apple.com:2195', $err,
			// $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

			$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr,60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
			// if (!$fp)
			// exit("Failed to connect: $err $errstr" . PHP_EOL);

			// echo 'Connected to APNS' . PHP_EOL;

			// Create the payload body
			$body['aps'] = array(
			'alert' => $message,
			'sound' => 'default',
			'badge'=>$badge,
			'section'=>$section,
			'content-available'=>'1'
			);

			// Encode the payload as JSON
			$payload = json_encode($body);

			// Build the binary notification
			$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

			// Send it to the server
			$result = fwrite($fp, $msg, strlen($msg));
			// Close the connection to the server
			//fclose($fp);

			if (!$result)
			return false;
			//echo 'Message not delivered' . PHP_EOL;
			else
			return true;
			//echo 'Message successfully delivered' . PHP_EOL;
		fclose($fp);
			}
?>